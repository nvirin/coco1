## 2.1.0 (2015-09-28)

* Added a priority to allow controlling the order of voters
* Added new templating features to the templating helper
* Added the necessary configuration for new Twig features of KnpMenu 2.1
* Added a menu provider registering builders as services
* Removed usage of deprecated API to run on Symfony 2.7 without warning

## 2.0.0 (2014-08-01)

* Updated to KnpMenu 2 stable 

## 2.0.0 alpha 1 (2013-06-23)

* Updated the bundle for KnpMenu 2.0.0 alpha1

## 1.1.2 (2013-05-25)

* Updated the composer constraint to allow Symfony 2.3 and above

## 1.1.1 (2012-11-28)

* Made the bundle compatible with Symfony 2.2

## 1.1.0 (2012-05-17)

* Updated bundle for KnpMenu 1.1
* Added bundle inheritance support in the BundleAliasProvider
* Added parameters for the default options of the ListRenderer and TwigRenderer

## 1.0.0 (2012-05-03)

* Initial release of the new bundle based on KnpMenu
