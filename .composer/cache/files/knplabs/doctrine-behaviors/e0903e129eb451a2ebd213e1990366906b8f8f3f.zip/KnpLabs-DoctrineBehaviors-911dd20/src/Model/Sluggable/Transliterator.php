<?php
/**
 * @author Lusitanian
 * Freely released with no restrictions, re-license however you'd like!
 */

namespace Knp\DoctrineBehaviors\Model\Sluggable;

/**
* Transliteration utility
*/
class Transliterator extends \Behat\Transliterator\Transliterator
{

}
