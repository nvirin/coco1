<tr>
    <td></td>
    <td>
        <?php echo $view['form']->widget($form) ?>
    </td>
</tr>
