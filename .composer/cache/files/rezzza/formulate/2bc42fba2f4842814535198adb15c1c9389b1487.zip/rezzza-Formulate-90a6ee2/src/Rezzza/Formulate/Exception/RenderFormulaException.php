<?php

namespace Rezzza\Formulate\Exception;

/**
 * RenderFormulaException
 *
 * @package Formulate
 * @author Stephane PY <py.stephane1@gmail.com>
 */
class RenderFormulaException extends \Exception
{
}
