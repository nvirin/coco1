<?php

namespace Buzz\Exception;

/**
 * Thrown whenever a required call-flow is not respected.
 */
class LogicException extends \LogicException implements ExceptionInterface
{
}
