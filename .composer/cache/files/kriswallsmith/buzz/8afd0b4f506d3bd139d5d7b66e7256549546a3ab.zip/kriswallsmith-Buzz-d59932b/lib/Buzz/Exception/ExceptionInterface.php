<?php

namespace Buzz\Exception;

/**
 * Marker interface to denote exceptions thrown from the Buzz context.
 */
interface ExceptionInterface
{
}
