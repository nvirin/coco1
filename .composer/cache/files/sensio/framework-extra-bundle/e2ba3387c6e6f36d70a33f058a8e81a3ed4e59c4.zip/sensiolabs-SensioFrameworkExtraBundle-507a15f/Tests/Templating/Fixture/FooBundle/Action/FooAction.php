<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\FooBundle\Action;

class FooAction
{
}
