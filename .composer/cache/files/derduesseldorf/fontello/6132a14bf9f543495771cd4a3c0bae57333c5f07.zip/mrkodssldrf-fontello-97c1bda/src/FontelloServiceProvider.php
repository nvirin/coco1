<?php namespace Derduesseldorf\Fontello;

use Illuminate\Support\ServiceProvider;

class FontelloServiceProvider extends ServiceProvider {

	/**
	 * Indicates if loading of the provider is deferred.
	 *
	 * @var bool
	 */
	protected $defer = false;

	/**
	 * Bootstrap the application events.
	 *
	 * @return void
	 */
	public function boot()
	{
		$this->package('derduesseldorf/fontello', null, __DIR__.'/');
        require_once __DIR__.'/routes.php';
	}

	/**
	 * Register the service provider.
	 *
	 * @return void
	 */
	public function register()
	{
		$this->app['fontello'] = $this->app->share(function($app) {
            return new Fontello();
        });
	}

	/**
	 * Get the services provided by the provider.
	 *
	 * @return array
	 */
	public function provides()
	{
		return array('fontello');
	}

}
