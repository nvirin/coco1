<?php

return array(

    /** Paths */
    'folder'        => public_path('fontello/'),
    'storage'       => public_path('uploads/temp/'),

    /** Strings */
    'file'          => 'config.json',
    'session'       => 'fontellosession',
    'archive'       => 'fontello.zip',

);