# UPGRADE

### 1.0 to 2.0

 * All protected properties and methods have been updated to private except for entry points. This is mostly motivated
   for enforcing the encapsulation and easing backward compatibility.
