<?php

namespace JS\MysqlndBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JSMysqlndBundle extends Bundle
{
}
