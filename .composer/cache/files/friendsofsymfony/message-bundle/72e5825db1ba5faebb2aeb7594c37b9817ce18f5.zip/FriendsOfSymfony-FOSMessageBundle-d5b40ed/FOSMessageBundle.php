<?php

namespace FOS\MessageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle as BaseBundle;

class FOSMessageBundle extends BaseBundle
{
}
