Contributing
============

FOSMessageBundle is an open source project. When contributing please follow the Symfony2 coding standards and provide
test cases where possible.
