Using other UserBundles
=======================

By default, FOSMessageBundle depends on functionality provided by FOSUserBundle for some
of its forms. It is possible to use other providers but additional work must be performed.

Documentation on this process has not been contributed at this stage. (If you'd like to
contribute it a pull request is very welcome!).
