FOSMessageBundle Events
=======================

FOSMessageBundle will dispatch events inside the Symfony2 `EventDispatcher` which allows
you to write listeners to modify or augment behaviour of the MessageBundle process.

You can see definitions and explainations of each event as defined in
`Event\FOSMessageEvents`.

[Return to the documentation index](00-index.md)
