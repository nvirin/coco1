elfinder-component
==================

ElFinder Component for composer
