<?php
/**
 * Please run composer update from the root folder to run test cases
 */
define('PP_CONFIG_PATH', dirname(__FILE__));
if(file_exists(dirname(__FILE__) . '/../vendor/autoload.php')) {
    require dirname(__FILE__) . '/../vendor/autoload.php';
}
