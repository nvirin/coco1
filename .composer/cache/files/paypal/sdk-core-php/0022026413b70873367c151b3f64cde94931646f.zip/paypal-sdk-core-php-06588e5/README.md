
PayPal Core SDK - V1.2.0
========================

Prerequisites
-------------

 * PHP 5.2 and above
 * curl extension with support for OpenSSL
 * PHPUnit 3.5 for running test suite (Optional)
 * Composer (Optional - for running test cases)
