<?php 

namespace PayPal\Api;
use PayPal\Common\Model;

/**
 * 
 */
class Resource extends Model {



}