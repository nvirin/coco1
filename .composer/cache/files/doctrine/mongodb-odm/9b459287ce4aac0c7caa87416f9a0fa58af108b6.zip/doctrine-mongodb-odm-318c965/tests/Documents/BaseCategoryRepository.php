<?php

namespace Documents;

use Doctrine\ODM\MongoDB\DocumentRepository;

class BaseCategoryRepository extends DocumentRepository {}