<?php

namespace Documents\CustomRepository;

use Doctrine\ODM\MongoDB\DocumentRepository;

/**
 * @author Bulat Shakirzyanov <mallluhuct@gmail.com>
 */
class Repository extends DocumentRepository {}