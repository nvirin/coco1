<?php

namespace Mapping\Fixture\Yaml;

class Referencer
{
    private $id;

    private $referencedDocuments;
}