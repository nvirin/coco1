<?php

namespace Mapping\Fixture\Xml;

/**
 * Class Embedded
 * @package Mapping\Fixture\Xml
 * @author Fabian Sabau <fabian.sabau@socialbit.de>
 */
class Embedded
{
    private $subtitle;
}
