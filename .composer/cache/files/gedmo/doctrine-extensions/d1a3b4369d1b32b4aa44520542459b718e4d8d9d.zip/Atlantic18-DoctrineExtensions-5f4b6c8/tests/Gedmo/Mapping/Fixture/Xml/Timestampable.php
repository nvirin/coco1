<?php

namespace Mapping\Fixture\Xml;

class Timestampable
{
    private $id;

    private $created;

    private $updated;

    private $published;

    private $status;
}
