<?php

namespace Mapping\Fixture\Xml;

class Sluggable
{
    private $id;

    private $title;

    private $code;

    private $ean;

    private $slug;

    private $parent;
}
