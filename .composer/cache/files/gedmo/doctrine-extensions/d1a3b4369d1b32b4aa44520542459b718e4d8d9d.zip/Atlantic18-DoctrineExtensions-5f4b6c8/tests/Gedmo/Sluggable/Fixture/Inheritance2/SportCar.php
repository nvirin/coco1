<?php

namespace Sluggable\Fixture\Inheritance2;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 */
class SportCar extends Car
{
}
