<?php

namespace Mapping\Fixture\Xml;

class EmbeddedTranslatable
{
    private $subtitle;
}
