<?php

namespace Gedmo\Mapping\Mock\Extension\Encoder\Mapping\Event\Adapter;

use Gedmo\Mapping\Event\Adapter\ORM as BaseAdapterORM;

final class ORM extends BaseAdapterORM
{
}
