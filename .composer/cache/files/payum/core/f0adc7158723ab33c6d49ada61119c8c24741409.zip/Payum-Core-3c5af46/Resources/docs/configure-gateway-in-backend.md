# Configure gateway in backend

In [get it started](get_it_started.md) we showed you how to configure gateways in the code. 
Sometimes you may asked to store gateways (mostly gateway credentials) to a database for example. 
So the admin can edit them in the backend. Here's the basic example how to do it in plain php. 
   
## Configure

First we have to create an entity where we store information about a gateway. 
The model must implement `Payum\Core\Model\GatewayConfigInterface`.

_**Note**: In this chapter we use DoctrineStorage._

```php
<?php
namespace Acme\Payment\Entity;

use Doctrine\ORM\Mapping as ORM;
use Payum\Core\Model\GatewayConfig as BaseGatewayConfig;

/**
 * @ORM\Table
 * @ORM\Entity
 */
class GatewayConfig extends BaseGatewayConfig
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @var integer $id
     */
    protected $id;
}
```

Now, we have to create a storage for it and change the simple registry with dynamic one.

```php
<?php
//config.php

// ...

use Payum\Core\Bridge\Doctrine\Storage\DoctrineStorage;
use Payum\Core\Registry\DynamicRegistry;

// $objectManager is an instance of doctrine object manager.

$gatewayConfigStorage = new DoctrineStorage($objectManager, 'Acme\Payment\Entity\GatewayConfig');

$payum = new DynamicRegistry($gatewayConfigStorage, $payum);
```

## Store gateway config

```php
<?php
//create_config.php

include 'config.php';

$gatewayConfig = $gatewayConfigStorage->create();
$gatewayConfig->setGatewayName('paypal');
$gatewayConfig->setFactoryName('paypal_express_checkout_nvp');
$gatewayConfig->setConfig(array(
    'username' => 'EDIT ME',
    'password' => 'EDIT ME',
    'signature' => 'EDIT ME',
    'sandbox' => true,
));

$gatewayConfigStorage->update($gatewayConfig);
```

## Use gateway

```php
<?php
// prepare.php

include 'config.php';

$gateway = $payum->getGateway('paypal');
```

Back to [index](index.md).

 
 

