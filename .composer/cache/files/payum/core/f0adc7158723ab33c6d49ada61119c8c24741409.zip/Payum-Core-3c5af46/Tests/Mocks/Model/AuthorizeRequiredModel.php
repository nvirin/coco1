<?php
namespace Payum\Core\Tests\Mocks\Model;

class AuthorizeRequiredModel extends TestModel
{
}
