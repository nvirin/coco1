<?php
namespace Payum\Core\Tests\Mocks\Entity;

use Doctrine\ORM\Mapping as ORM;
use Payum\Core\Model\Token as BaseToken;

/**
 * @ORM\Entity
 */
class Token extends BaseToken
{
}
