<?php
namespace Payum\Core\Tests\Mocks\Request;

class AuthorizeRequest
{
}
