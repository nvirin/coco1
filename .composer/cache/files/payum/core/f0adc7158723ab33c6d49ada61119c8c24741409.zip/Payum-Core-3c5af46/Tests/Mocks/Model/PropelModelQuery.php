<?php
namespace Payum\Core\Tests\Mocks\Model;

class PropelModelQuery
{
    public static function create()
    {
        return new PropelModel();
    }
}
