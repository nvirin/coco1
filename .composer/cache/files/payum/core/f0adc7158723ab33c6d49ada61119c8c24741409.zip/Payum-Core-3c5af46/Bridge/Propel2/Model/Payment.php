<?php
namespace Payum\Core\Bridge\Propel2\Model;

use Payum\Core\Bridge\Propel2\Model\Base\Payment as BasePayment;

class Payment extends BasePayment
{
}
