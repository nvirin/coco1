<?php

namespace Payum\Core\Bridge\Propel\Model;

use om\BasePayment;
use Payum\Core\Model\PaymentInterface;

class Payment extends BasePayment implements PaymentInterface
{
}
