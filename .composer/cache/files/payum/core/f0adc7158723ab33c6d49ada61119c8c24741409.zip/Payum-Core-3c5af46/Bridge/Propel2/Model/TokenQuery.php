<?php
namespace Payum\Core\Bridge\Propel2\Model;

use Payum\Core\Bridge\Propel2\Model\Base\TokenQuery as BaseTokenQuery;

class TokenQuery extends BaseTokenQuery
{
}
