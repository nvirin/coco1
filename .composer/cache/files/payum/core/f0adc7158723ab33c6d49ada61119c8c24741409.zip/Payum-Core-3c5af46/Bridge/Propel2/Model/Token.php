<?php
namespace Payum\Core\Bridge\Propel2\Model;

use Payum\Core\Bridge\Propel2\Model\Base\Token as BaseToken;

class Token extends BaseToken
{
}
