<?php
namespace Payum\Core\Bridge\Propel2\Model;

use Payum\Core\Bridge\Propel2\Model\Base\PaymentQuery as BasePaymentQuery;

class PaymentQuery extends BasePaymentQuery
{
}
