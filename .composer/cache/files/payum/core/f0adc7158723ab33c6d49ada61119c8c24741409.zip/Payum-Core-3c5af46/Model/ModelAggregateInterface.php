<?php
namespace Payum\Core\Model;

interface ModelAggregateInterface
{
    /**
     * @return mixed
     */
    public function getModel();
}
