<?php
namespace Payum\Core\Model;

class Identificator extends Identity
{
}
