<?php
namespace Payum\Core\Model;

interface DetailsAggregateInterface
{
    /**
     * @return object|null
     */
    public function getDetails();
}
