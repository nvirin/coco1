<?php
namespace Payum\Core\Reply;

use Payum\Core\Exception\ExceptionInterface;

interface ReplyInterface extends ExceptionInterface
{
}
