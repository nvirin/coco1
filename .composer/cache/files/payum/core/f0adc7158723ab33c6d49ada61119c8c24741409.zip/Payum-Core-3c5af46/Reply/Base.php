<?php
namespace Payum\Core\Reply;

use Payum\Core\Exception\LogicException;

abstract class Base extends LogicException implements ReplyInterface
{
}
