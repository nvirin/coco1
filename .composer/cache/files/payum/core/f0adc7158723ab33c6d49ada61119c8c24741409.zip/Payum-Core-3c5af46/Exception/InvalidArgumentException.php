<?php
namespace Payum\Core\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
