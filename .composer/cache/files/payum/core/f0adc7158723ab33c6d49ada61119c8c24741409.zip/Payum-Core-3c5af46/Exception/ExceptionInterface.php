<?php
namespace Payum\Core\Exception;

interface ExceptionInterface
{
}
