<?php
namespace Payum\Core\Exception;

class UnsupportedApiException extends InvalidArgumentException
{
}
