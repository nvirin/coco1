<?php
namespace Payum\Core\Exception;

class LogicException extends \LogicException implements ExceptionInterface
{
}
