<?php
namespace Payum\Core\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
