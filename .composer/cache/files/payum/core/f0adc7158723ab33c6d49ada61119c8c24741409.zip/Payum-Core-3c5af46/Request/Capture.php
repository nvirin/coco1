<?php
namespace Payum\Core\Request;

class Capture extends Generic
{
}
