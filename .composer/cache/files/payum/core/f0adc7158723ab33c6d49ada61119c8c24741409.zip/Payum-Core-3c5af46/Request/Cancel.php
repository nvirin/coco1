<?php
namespace Payum\Core\Request;

class Cancel extends Generic
{
}
