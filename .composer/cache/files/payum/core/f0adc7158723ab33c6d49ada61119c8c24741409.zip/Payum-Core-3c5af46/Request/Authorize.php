<?php
namespace Payum\Core\Request;

class Authorize extends Generic
{
}
