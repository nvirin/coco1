<?php
namespace Payum\Core\Request;

class Sync extends Generic
{
}
