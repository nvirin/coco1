<?php
namespace Payum\Core\Request;

class Refund extends Generic
{
}
