<?php
namespace Payum\Core\Request;

class Notify extends Generic
{
}
