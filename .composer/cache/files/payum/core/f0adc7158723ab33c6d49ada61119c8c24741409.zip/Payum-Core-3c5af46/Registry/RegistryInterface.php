<?php
namespace Payum\Core\Registry;

interface RegistryInterface extends GatewayRegistryInterface, GatewayFactoryRegistryInterface, StorageRegistryInterface
{
}
