<?php

namespace Bazinga\Bundle\GeocoderBundle\Mapping\Exception;

/**
 * @author Markus Bachmann <markus.bachmann@bachi.biz>
 */
class MappingException extends \Exception
{
}
