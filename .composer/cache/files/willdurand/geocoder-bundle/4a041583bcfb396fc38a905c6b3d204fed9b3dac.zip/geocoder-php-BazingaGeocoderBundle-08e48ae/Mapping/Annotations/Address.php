<?php

namespace Bazinga\Bundle\GeocoderBundle\Mapping\Annotations;

/**
 * @author Markus Bachmann <markus.bachmann@bachi.biz>
 *
 * @Annotation
 */
class Address
{
}
