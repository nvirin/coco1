<?php

namespace Geocoder\Exception;

class CollectionIsEmpty extends \RuntimeException implements Exception
{
}
