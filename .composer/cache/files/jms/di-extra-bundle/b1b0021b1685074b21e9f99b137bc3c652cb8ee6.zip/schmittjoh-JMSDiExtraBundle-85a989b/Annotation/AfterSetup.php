<?php

namespace JMS\DiExtraBundle\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 *
 * @author Johannes M. Schmitt <schmittjoh@gmail.com>
 */
final class AfterSetup
{
}
