This document details all changes between different versions of JMSDiExtraBundle:

1.3
---

- added a generic implementation for lazy service collections (maps, and sequences)
- added option to disable controller warming entirely, or for selected bundles
- added support for the strict flag to the @Inject annotation

1.2
---

- added @SecurityFunction annotation

1.1
---

- added option to configure automatic controller injections for certain properties,
  and setter methods

1.0
---

Initial release  
