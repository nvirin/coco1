<?php

namespace JMS\DiExtraBundle\Tests\Metadata\Driver\Fixture;

class MethodMetaProcessor
{
    /**
     * @CustomAnnotation(key="omg", value="fancy")
     */
    public function test()
    {}
}
