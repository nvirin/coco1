<?php

namespace JMS\DiExtraBundle\Tests\Metadata\Driver\Fixture;

/**
 * @CustomAnnotation(value="works")
 */
class ClassMetaProcessor
{}
