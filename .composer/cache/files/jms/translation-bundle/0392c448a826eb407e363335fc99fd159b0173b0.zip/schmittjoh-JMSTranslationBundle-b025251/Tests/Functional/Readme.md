# Functional tests

In this folder are functional tests. We have a TestBundle in the Fixtures folder that is used to 
test extractors, controllers etc. We also have special config to test different users setup. 

The functional tests are very helpful when we test with different Symfony versions. 