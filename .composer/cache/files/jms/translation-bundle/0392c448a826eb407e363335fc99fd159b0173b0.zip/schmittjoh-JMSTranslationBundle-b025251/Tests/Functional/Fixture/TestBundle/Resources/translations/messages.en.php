<?php

return array(
    'text.apples_remaining' => '{0} There is no apple|{1} There is one apple|]1,Inf] There are %count% apples',
    'text.foo' => 'foobar',
);
