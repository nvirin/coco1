<?php

namespace CG\Tests\Proxy\Fixture;
