CG library provides a toolset for generating PHP code
=====================================================

Overview
--------

This library provides some tools that you commonly need for generating PHP code.
One of it's strength lies in the enhancement of existing classes with behaviors.

