<?php

namespace CG\Tests\Generator\Fixture\SubFixture;

class Baz {}