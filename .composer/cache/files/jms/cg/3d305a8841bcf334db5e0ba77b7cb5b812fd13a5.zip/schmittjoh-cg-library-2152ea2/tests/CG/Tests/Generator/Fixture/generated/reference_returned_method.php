public function & foo()
{
}

