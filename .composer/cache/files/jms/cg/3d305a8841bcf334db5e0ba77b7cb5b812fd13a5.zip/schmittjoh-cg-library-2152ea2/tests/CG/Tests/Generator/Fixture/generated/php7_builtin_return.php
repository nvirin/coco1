function foo(): bool
{
}