public function foo(callable $bar)
{
}

