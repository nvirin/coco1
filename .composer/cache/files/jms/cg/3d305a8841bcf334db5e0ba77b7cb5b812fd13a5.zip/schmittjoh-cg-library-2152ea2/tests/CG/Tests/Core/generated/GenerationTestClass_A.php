class GenerationTestClass
{
    const a = 'foo';
    const b = 'bar';

    public $a;
    public $b;

    public function a()
    {
    }

    public function b()
    {
    }
}