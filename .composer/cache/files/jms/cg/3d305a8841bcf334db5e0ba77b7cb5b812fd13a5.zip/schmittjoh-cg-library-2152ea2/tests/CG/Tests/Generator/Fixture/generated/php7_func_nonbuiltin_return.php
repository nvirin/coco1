function foo(): \Foo
{
}