<?php

namespace Metadata\Tests\Driver\Fixture\B;

class B { }