<?php

namespace Metadata\Tests\Fixtures\ComplexHierarchy;

interface InterfaceB
{
}
