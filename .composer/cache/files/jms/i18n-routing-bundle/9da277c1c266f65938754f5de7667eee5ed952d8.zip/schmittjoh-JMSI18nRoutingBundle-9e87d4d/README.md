# JMSI18nRoutingBundle

i18n Routing Bundle for the Symfony Framework

Build Status: [![Build Status](https://secure.travis-ci.org/jms/JMSI18nRoutingBundle.png?branch=master)](http://travis-ci.org/jms/JMSI18nRoutingBundle)

Documentation: 
[Resources/doc](http://jmsyst.com/bundles/JMSI18nRoutingBundle)
    

Code License:
[Resources/meta/LICENSE](https://github.com/schmittjoh/JMSI18nRoutingBundle/blob/master/Resources/meta/LICENSE)


Documentation License:
[Resources/doc/LICENSE](https://github.com/schmittjoh/JMSI18nRoutingBundle/blob/master/Resources/doc/LICENSE)
