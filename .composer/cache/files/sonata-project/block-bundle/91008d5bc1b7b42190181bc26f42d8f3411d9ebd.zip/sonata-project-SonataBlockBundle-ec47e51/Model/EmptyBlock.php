<?php
/*
 * This file is part of the Sonata project.
 *
 * (c) Thomas Rabaix <thomas.rabaix@sonata-project.org>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Sonata\BlockBundle\Model;

use Sonata\BlockBundle\Model\Block;

/**
 * EmptyBlock model to be used to return an empty result if a block is not found or not valid
 */
class EmptyBlock extends Block
{
}
