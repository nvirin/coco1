Sonata Block Bundle
====================

[![Build Status](https://secure.travis-ci.org/sonata-project/SonataBlockBundle.png)](https://secure.travis-ci.org/#!/sonata-project/SonataBlockBundle)

This bundle provides a block management solution.

Check out the documentation on [http://sonata-project.org/bundles/block/master/doc/index.html](http://sonata-project.org/bundles/block/master/doc/index.html)

**Google Groups**: For questions and proposals you can post on this google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): Only for user questions
* [Sonata Devs](https://groups.google.com/group/sonata-devs): Only for devs

License
-------

This bundle is available under the [MIT license](Resources/meta/LICENSE).
