===============
Sonata exporter
===============

Sonata exporter is a library to export data from one source to an output in an efficient way. It is highly performance-oriented.

Summary
=======

.. toctree::
   :maxdepth: 1

    Introduction <reference/introduction>
    Installation <reference/installation>
    Sources <reference/sources>
    Outputs <reference/outputs>


