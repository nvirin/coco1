========================
Sonata demo installation
========================

Pre-requisites
==============

- Git
- PHP 5.3.3 and up
- `Composer <https://getcomposer.org/>`_

Installation
============

Add the project in your project dependencies:

.. code-block:: bash

    php composer.phar require sonata-project/exporter dev-master


And voilà! You're ready to go.
