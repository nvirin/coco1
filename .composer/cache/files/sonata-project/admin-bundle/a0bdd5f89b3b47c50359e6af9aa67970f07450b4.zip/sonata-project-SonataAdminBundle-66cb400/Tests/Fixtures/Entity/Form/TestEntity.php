<?php

namespace Sonata\AdminBundle\Tests\Fixtures\Entity\Form;

class TestEntity
{
}
