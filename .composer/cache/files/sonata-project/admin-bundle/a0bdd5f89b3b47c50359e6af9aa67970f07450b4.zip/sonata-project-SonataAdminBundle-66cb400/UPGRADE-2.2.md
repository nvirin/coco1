UPGRADE FROM 2.1 to 2.2
=======================

### Form

  * Refactoring the general layout to be more compact
  * Remove the collapsing option to migrate to tabbed form layout
  * Add tab menu to edit form
  * Fix deprecated calls to the Form API

