### 1.0.3 (2014-12-16)

  * Correctly handle lookups into scalar values (@toin0u)

### 1.0.2 (2014-09-03)

  * Allow `assoc_in` to override non-array values (@marcioAlmada)

### 1.0.1 (2014-07-06)

  * Support for null values
  * Micro-optimization (@AnhNhan)

### 1.0.0 (2014-01-08)

  * Initial release
