ElFinderPHP
===========

ElFinderPHP is PHP 5.4 modification of server side ElFinder.

Based on [@nao-pon](https://github.com/nao-pon/)  [fork of ElFinder] (https://github.com/nao-pon/elFinder/)

Provides support for the following backend:

1. LocalVolumeDriver
2. Dropbox driver
3. FTP Driver
4. S3 Driver
5. MySql driver
6. Flysystem support (via modified @barryvdh [driver](https://github.com/barryvdh/elfinder-flysystem-driver))
