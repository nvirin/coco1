<?php

$resp = new Symfony\Component\HttpFoundation\Response('Sorry, a server error happened', 500);
