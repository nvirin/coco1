<?php
    $resp = new Symfony\Component\HttpFoundation\Response();
    $resp->headers->set('X-Mink-Test', 'response-headers');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Response headers</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>
<body>
    <h1>Response headers</h1>
</body>
</html>

