<?php

$resp = new Symfony\Component\HttpFoundation\RedirectResponse('/redirect_destination.html');
