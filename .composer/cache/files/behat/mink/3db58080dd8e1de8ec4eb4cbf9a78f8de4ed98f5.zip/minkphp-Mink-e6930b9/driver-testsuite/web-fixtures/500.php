<?php header("HTTP/1.0 500 Server Error") ?>
Sorry, a server error happened
