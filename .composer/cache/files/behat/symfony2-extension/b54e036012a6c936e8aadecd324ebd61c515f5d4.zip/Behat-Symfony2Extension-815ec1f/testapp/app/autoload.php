<?php

$loader = require(__DIR__.'/../../vendor/autoload.php');
$loader->add('Behat\\Sf2DemoBundle', __DIR__.'/../src');
